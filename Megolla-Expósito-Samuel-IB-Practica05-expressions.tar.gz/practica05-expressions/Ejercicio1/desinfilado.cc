#include<iostream>

using namespace std;

int main(){

	char character{};
	cin>>character;

	static_cast<int>(character);
	character=character+32;
	static_cast<char>(character);
	cout<<character<<endl;



	return 0;
}
