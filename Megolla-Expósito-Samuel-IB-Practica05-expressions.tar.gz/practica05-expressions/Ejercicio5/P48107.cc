#include<iostream>

using namespace std;

int main(){
	
	int a{0},b{0},resultado{0},resto{0};

	cin>>a;
	cin>>b;

	resultado = a/b;
	resto = a%b;

	cout<<resultado<<" "<<resto<<endl;



	return 0;
}
