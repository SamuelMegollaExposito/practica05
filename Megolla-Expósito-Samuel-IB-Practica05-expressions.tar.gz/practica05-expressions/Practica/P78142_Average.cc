/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Samuel Megolla Expósito
 * @date 3 noviembre 2022
 * @brief Average
 * Write a program that reads a sequence of numbers and prints their average.
 *
 *  Input
 *Input consists of a non-empty sequence of strictly positive real numbers.
 *Output
 *Print the average of the numbers with 2 digits after the decimal point.
 */
#include<iostream>
#include<iomanip>
using namespace std;

int main(){

double number{0},total{0},counter{0};

	while(cin>>number){
	
	total+=number;
	counter++;
	
	}
	
	counter=total/counter;
	cout<<fixed<<setprecision(2)<<total<<endl;




return 0;
}
