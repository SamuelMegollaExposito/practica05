/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Samuel Megolla Expósito
 * @date 3 noviembre 2022
 * @brief Average
 * Write a program that reads three words a, b and c, and prints a line with c,  *b and a in this order.
 *Input
 *Input consists of three words on a line.
 *Output
 *Print a line with the three words in reverse order, separated with spaces.
 */

#include<iostream>
#include<string.h>
#include<strings.h>

using namespace std;

int main(){

    string palabra1{},palabra2{},palabra3{};

    cin>>palabra1>>palabra2>>palabra3;

    cout<<palabra3<<" "<<palabra2<<" "<<palabra1<<endl;

    return 0;
}
