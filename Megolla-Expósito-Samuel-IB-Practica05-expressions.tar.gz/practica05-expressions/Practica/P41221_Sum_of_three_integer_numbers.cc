/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Samuel Megolla Expósito
 * @date 3 noviembre 2022
 * @brief Sum of three integer numbers
 * 
 */
#include<iostream>

using namespace std;

int main(){

	int a{0},b{0},c{0},resultado{0};
	
	cin>>a;
	cin>>b;
	cin>>c;
	resultado = a + b + c;

	cout<<resultado<<endl;
	
return 0;
}
