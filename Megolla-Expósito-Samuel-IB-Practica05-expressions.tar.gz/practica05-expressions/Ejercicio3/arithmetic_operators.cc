#include<iostream>

using namespace std;

int main(){

	int number1{0},number2{0},suma{0},resta{0},multiplicacion{0},division{0},modulo{0};
					
	cin>>number1>>number2;

	suma = number1 + number2;
	resta = number1 - number2;
	multiplicacion = number1 * number2;
	division = number1 / number2;
	modulo = number1 % number2;

	cout<<number1<<" + "<<number2<<" "<<"="<<" "<<suma<<endl;
	cout<<number1<<" - "<<number2<<" "<<"="<<" "<<resta<<endl;
	cout<<number1<<" * "<<number2<<" "<<"="<<" "<<multiplicacion<<endl;
	cout<<number1<<" / "<<number2<<" "<<"="<<" "<<division<<endl;
	cout<<number1<<" % "<<number2<<" "<<"="<<" "<<division<<endl;
	
	if(number1>number2){
	cout<<number1<<" > "<<number2<<endl;
	}
	if(number1<number2){
	cout<<number1<<" < "<<number2<<endl;
	}
	if(number1==number2){
	cout<<number1<<" = "<<number2<<endl;
	}








	return 0;
}
